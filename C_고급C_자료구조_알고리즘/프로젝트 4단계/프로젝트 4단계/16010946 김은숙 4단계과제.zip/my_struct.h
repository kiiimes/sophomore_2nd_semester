#ifndef MY_STRUCT_H
#define MY_STRUCT_H

struct TEL
{
    char *name;
	char *phone;
	char *birth;
};
#endif