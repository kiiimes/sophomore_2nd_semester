#ifndef MY_DEFINE_H
#define MY_DEFINE_H

#include "my_struct.h"

typedef struct TEL tel;
#endif