
import java.awt.*;

public class DrawData 
{
	public int nDrawMode;
	public int nSize;
	public Color drawColor;
	public boolean nFill;
	public Point ptOne, ptTwo;
	
	public DrawData()
	{
		nDrawMode = DrawConstants.NONE;
		nSize = 1;
		nFill = false;
		drawColor = Color.black;
		ptOne = new Point();
		ptTwo = new Point();
	}
	
	
}//DrawData class
