import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DrawingPanel extends JPanel {
	
	public DrawingPanel() {
		setBackground(Color.white);
		setLayout(null);
	}
	
	//���⼭ �׸��� �׸�������
	public void paintComponent(Graphics page) {
		super.paintComponent(page);
	
		
	}
}
