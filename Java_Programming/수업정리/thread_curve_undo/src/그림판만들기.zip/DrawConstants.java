import java.awt.*;
public class DrawConstants {

	public static final String[] MENU = {"POINT","LINE","RECT","OVAL","",""};
	public static final Color[] EXIT	 = {Color.white,Color.black};
	public static final Color[] ENTER	 = {Color.white,Color.red};
}//����鸸 �����ϴ� Ŭ����
