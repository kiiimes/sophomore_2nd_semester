public class ValueGet {
	private int currValue;
	private int voltValue;
	private int powerValue;
	
	public int getCurrValue() {
		return currValue;
	}
	public void setCurrValue(int currValue) {
		this.currValue = currValue;
	}
	public int getVoltValue() {
		return voltValue;
	}
	public void setVoltValue(int voltValue) {
		this.voltValue = voltValue;
	}
	public int getPowerValue() {
		return powerValue;
	}
	public void setPowerValue(int powerValue) {
		this.powerValue = powerValue;
	}
	
	
}
